CREATE TABLE "Student" (
"ID" INTEGER,
"Name" VARCHAR(15)
);
INSERT INTO "Student" ("ID", "Name") VALUES(10,'Venus');
