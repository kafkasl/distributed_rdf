CREATE TABLE Student (
Name varchar(50)
);
INSERT INTO Student VALUES ('Venus')
