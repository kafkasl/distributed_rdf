CREATE TABLE Student (
ID integer,
Name varchar(50),
Sport varchar (50),
PRIMARY KEY (ID,Name)
);
INSERT INTO Student (ID, Name,Sport) VALUES(10,'Venus Williams','Tennis');
